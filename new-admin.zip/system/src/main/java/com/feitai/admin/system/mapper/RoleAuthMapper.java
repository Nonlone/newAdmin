package com.feitai.admin.system.mapper;

import com.feitai.admin.system.model.RoleAuth;
import tk.mybatis.mapper.common.Mapper;

public interface RoleAuthMapper extends Mapper<RoleAuth> {
}
