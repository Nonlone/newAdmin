package com.feitai.admin.system.mapper;

import com.feitai.admin.system.model.DictionaryType;
import tk.mybatis.mapper.common.Mapper;

public interface DictionaryTypeMapper extends Mapper<DictionaryType> {
}
