package com.feitai.admin.system.mapper;

import com.feitai.admin.system.model.Role;
import tk.mybatis.mapper.common.Mapper;

public interface RoleMapper extends Mapper<Role> {
}
