package com.feitai.admin.system.mapper;

import com.feitai.admin.system.model.User;
import tk.mybatis.mapper.common.Mapper;

public interface SysUserMapper extends Mapper<User> {
}
