package com.feitai.admin.system.mapper;

import com.feitai.admin.system.model.Permission;
import tk.mybatis.mapper.common.Mapper;

public interface PermissionMapper extends Mapper<Permission> {
}
