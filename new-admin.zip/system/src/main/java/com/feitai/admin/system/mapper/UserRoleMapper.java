package com.feitai.admin.system.mapper;

import com.feitai.admin.system.model.UserRole;
import tk.mybatis.mapper.common.Mapper;

public interface UserRoleMapper extends Mapper<UserRole> {
}
