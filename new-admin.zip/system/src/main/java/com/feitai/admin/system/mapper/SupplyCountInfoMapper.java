package com.feitai.admin.system.mapper;

import com.feitai.admin.system.model.SupplyCountInfo;
import tk.mybatis.mapper.common.Mapper;

/**
 * detail:
 * author:
 * date:2018/11/30
 */
public interface SupplyCountInfoMapper extends Mapper<SupplyCountInfo> {
}
