package com.feitai.admin.system.service;

import com.feitai.admin.core.service.DynamitSupportService;
import com.feitai.admin.system.model.SupplyCountInfo;
import org.springframework.stereotype.Service;

/**
 * detail:
 * author:
 * date:2018/11/30
 */
@Service
public class SupplyCountInfoService extends DynamitSupportService<SupplyCountInfo> {



}
