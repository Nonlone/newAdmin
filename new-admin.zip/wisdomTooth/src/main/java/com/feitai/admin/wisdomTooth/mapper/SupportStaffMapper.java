package com.feitai.admin.wisdomTooth.mapper;

import com.feitai.admin.wisdomTooth.model.SupportStaff;
import tk.mybatis.mapper.common.Mapper;

public interface SupportStaffMapper extends Mapper<SupportStaff> {
}
