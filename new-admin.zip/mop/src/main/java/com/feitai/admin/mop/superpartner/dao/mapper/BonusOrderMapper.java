package com.feitai.admin.mop.superpartner.dao.mapper;

import com.feitai.admin.mop.superpartner.dao.entity.BonusOrder;
import tk.mybatis.mapper.common.Mapper;

public interface BonusOrderMapper extends Mapper<BonusOrder> {
}