package com.feitai.admin.mop.base;

/**
 * @Author qiuyunlong
 */
public class Symbol {

    private Symbol(){}

    public static final String EMPTY_JSON = "{}";
    public static final String EMPTY_JSON_ARRAY = "[]";
}
