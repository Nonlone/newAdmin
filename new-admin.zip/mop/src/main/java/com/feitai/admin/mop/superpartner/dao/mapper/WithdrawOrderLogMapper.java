package com.feitai.admin.mop.superpartner.dao.mapper;

import com.feitai.admin.mop.superpartner.dao.entity.WithdrawOrderLog;
import tk.mybatis.mapper.common.Mapper;

public interface WithdrawOrderLogMapper extends Mapper<WithdrawOrderLog> {
}