package com.feitai.admin.mop.superpartner.request;

import lombok.Data;

/**
 * @Author qiuyunlong
 */
@Data
public class PartnerUpdateRequest {

    private Long userId;

    private String settle;

    private String operator;

}
