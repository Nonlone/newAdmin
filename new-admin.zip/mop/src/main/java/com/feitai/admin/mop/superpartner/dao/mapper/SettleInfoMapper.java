package com.feitai.admin.mop.superpartner.dao.mapper;

import com.feitai.admin.mop.superpartner.dao.entity.SettleInfo;
import tk.mybatis.mapper.common.Mapper;

public interface SettleInfoMapper extends Mapper<SettleInfo> {
}