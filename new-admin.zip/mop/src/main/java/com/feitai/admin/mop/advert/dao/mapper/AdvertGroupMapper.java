package com.feitai.admin.mop.advert.dao.mapper;

import com.feitai.admin.mop.advert.dao.entity.AdvertGroup;
import tk.mybatis.mapper.common.Mapper;

public interface AdvertGroupMapper extends Mapper<AdvertGroup> {
}