package com.feitai.admin.mop.superpartner.dao.mapper;

import com.feitai.admin.mop.superpartner.dao.entity.ReceiverInfo;
import tk.mybatis.mapper.common.Mapper;

public interface ReceiverInfoMapper extends Mapper<ReceiverInfo> {
}