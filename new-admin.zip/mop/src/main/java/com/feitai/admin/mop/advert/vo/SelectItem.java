package com.feitai.admin.mop.advert.vo;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @Author qiuyunlong
 */
@Data
@AllArgsConstructor
public class SelectItem {
    private String text;
    private Long value;
}
