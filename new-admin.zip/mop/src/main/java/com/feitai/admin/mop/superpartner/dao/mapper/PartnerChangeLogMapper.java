package com.feitai.admin.mop.superpartner.dao.mapper;

import com.feitai.admin.mop.superpartner.dao.entity.PartnerChangeLog;
import tk.mybatis.mapper.common.Mapper;

public interface PartnerChangeLogMapper extends Mapper<PartnerChangeLog> {
}