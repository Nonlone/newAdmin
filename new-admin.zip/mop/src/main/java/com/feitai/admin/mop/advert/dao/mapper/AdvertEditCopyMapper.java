package com.feitai.admin.mop.advert.dao.mapper;

import com.feitai.admin.mop.advert.dao.entity.AdvertEditCopy;
import tk.mybatis.mapper.common.Mapper;

public interface AdvertEditCopyMapper extends Mapper<AdvertEditCopy> {
}