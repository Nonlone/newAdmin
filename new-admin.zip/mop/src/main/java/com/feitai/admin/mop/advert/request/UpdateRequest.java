package com.feitai.admin.mop.advert.request;

import lombok.Data;

/**
 * @Author qiuyunlong
 */
@Data
public class UpdateRequest {

    private Long userId;

    private String settle;

    private String operator;

}
