package com.feitai.admin.backend.customer.mapper;

import com.feitai.admin.backend.customer.entity.IdCardDataExtend;
import tk.mybatis.mapper.common.Mapper;

/**
 * detail:
 * author:
 * date:2018/10/15
 */
public interface IdCardDataExtendMapper extends Mapper<IdCardDataExtend> {
}
