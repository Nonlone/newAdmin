package com.feitai.admin.backend.opencard.mapper;

import com.feitai.admin.backend.opencard.entity.CardMore;
import tk.mybatis.mapper.common.Mapper;

public interface CardMoreMapper extends Mapper<CardMore> {
}
