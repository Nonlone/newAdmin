package com.feitai.admin.backend.customer.mapper;

import com.feitai.admin.backend.customer.entity.ProductType;
import tk.mybatis.mapper.common.Mapper;

public interface ProductTypeMapper extends Mapper<ProductType> {
}
