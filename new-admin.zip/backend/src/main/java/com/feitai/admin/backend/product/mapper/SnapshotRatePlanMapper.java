package com.feitai.admin.backend.product.mapper;

import com.feitai.admin.backend.product.entity.SnapshotRatePlan;
import tk.mybatis.mapper.common.Mapper;

public interface SnapshotRatePlanMapper extends Mapper<SnapshotRatePlan> {
}
