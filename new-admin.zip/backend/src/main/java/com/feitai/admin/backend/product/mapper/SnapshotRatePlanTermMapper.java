package com.feitai.admin.backend.product.mapper;

import com.feitai.admin.backend.product.entity.SnapshotRatePlanTerm;
import tk.mybatis.mapper.common.Mapper;

public interface SnapshotRatePlanTermMapper extends Mapper<SnapshotRatePlanTerm> {
}
