package com.feitai.admin.backend.config.mapper;

import com.feitai.admin.backend.config.entity.ChannelPrimary;
import tk.mybatis.mapper.common.Mapper;

public interface ChannelPrimaryMapper extends Mapper<ChannelPrimary> {
}
