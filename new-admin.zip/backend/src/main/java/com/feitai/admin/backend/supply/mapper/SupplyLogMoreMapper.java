package com.feitai.admin.backend.supply.mapper;

import com.feitai.admin.backend.supply.entity.SupplyLogMore;
import tk.mybatis.mapper.common.Mapper;

public interface SupplyLogMoreMapper extends Mapper<SupplyLogMore> {
}
