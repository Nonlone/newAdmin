package com.feitai.admin.backend.supply.mapper;

import com.feitai.admin.backend.supply.entity.SupplyRequirementMore;
import tk.mybatis.mapper.common.Mapper;

/**
 * detail:
 * author:
 * date:2018/11/19
 */
public interface SupplyRequirementMoreMapper extends Mapper<SupplyRequirementMore> {
}
