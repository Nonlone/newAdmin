package com.feitai.admin.backend.supply.vo;

import lombok.Data;

/**
 * detail:
 * author:
 * date:2018/11/30
 */
@Data
public class LoanSupplyInfo {

    private String supplyCode;

    private String supplyType;

    private String supplyInfo;

    private String[] supplyInfos;

    private String ifPlural;

}
