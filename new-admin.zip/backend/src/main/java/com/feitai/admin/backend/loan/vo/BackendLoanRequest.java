package com.feitai.admin.backend.loan.vo;

import lombok.Data;

/**
 * detail:
 * author:
 * date:2018/11/27
 */
@Data
public class BackendLoanRequest {

    private Long loanOrderId;

}
