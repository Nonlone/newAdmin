package com.feitai.admin.backend.supply.vo;

import lombok.Data;
import lombok.ToString;

/**
 * detail:
 * author:
 * date:2018/11/30
 */
@Data
@ToString
public class PicturesInfo {

    private String content;

    private String endFlag;

    private String type;

}
