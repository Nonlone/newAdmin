package com.feitai.admin.backend.product.mapper;

import com.feitai.admin.backend.product.entity.RatePlanMore;
import tk.mybatis.mapper.common.Mapper;

public interface RatePlanMoreMapper extends Mapper<RatePlanMore> {
}
