package com.feitai.admin.backend.loan.mapper;

import com.feitai.admin.backend.loan.entity.LoanOrderMore;
import tk.mybatis.mapper.common.Mapper;

public interface LoanOrderMoreMapper extends Mapper<LoanOrderMore> {
}
