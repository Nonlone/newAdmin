package com.feitai.admin.backend.loan.mapper;

import com.feitai.admin.backend.loan.entity.RepayOrderMore;
import tk.mybatis.mapper.common.Mapper;

public interface RepayOrderMoreMapper extends Mapper<RepayOrderMore> {
}
