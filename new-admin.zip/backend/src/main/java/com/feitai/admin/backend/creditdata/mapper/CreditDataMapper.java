package com.feitai.admin.backend.creditdata.mapper;

import com.feitai.admin.backend.creditdata.model.CreditData;
import tk.mybatis.mapper.common.Mapper;

/**
 * detail:
 * author:
 * date:2018/10/25
 */
public interface CreditDataMapper extends Mapper<CreditData> {
}
