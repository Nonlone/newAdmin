package com.feitai.admin.backend.config.mapper;

import com.feitai.admin.backend.config.entity.AppConfigType;
import tk.mybatis.mapper.common.Mapper;

public interface AppConfigTypeMapper extends Mapper<AppConfigType> {
}
