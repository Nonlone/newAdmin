/**
 * @author 
 * @version 1.0
 * @since  2018-07-25 09:42:04
 * @desc 产品表
 */

package com.feitai.admin.backend.product.service;

import com.feitai.admin.core.service.ClassPrefixDynamicSupportService;
import com.feitai.jieya.server.dao.product.model.Product;
import org.springframework.stereotype.Service;

@Service
public class  ProductService extends ClassPrefixDynamicSupportService<Product> {


}
