
package com.feitai.admin.backend.product.service;

import com.feitai.admin.backend.product.entity.SnapshotRatePlan;
import com.feitai.admin.core.service.ClassPrefixDynamicSupportService;
import org.springframework.stereotype.Service;

@Service
public class SnapshotRatePlanService extends ClassPrefixDynamicSupportService<SnapshotRatePlan> {

}
