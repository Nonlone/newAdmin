
package com.feitai.admin.backend.product.service;

import com.feitai.admin.backend.product.entity.SnapshotRatePlanTerm;
import com.feitai.admin.core.service.ClassPrefixDynamicSupportService;
import org.springframework.stereotype.Service;


@Service
public class SnapshotRatePlanTermService extends ClassPrefixDynamicSupportService<SnapshotRatePlanTerm> {

}
